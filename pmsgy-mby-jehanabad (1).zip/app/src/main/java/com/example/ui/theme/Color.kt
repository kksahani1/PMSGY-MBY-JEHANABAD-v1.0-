package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val GoldPrimary = Color(0xFFD4AF37)
val GoldDark = Color(0xFFB8860B)
val GoldDarkBar = Color(0xFF7A5C0A)
val GoldLight = Color(0xFFFFF9E6)
val GoldAccent = Color(0xFFFFD700)

val GovMaroon = Color(0xFF7A0000)
val GovTextDark = Color(0xFF3B2800)

val LightBackground = Color(0xFFFFFDF5)
val LightSurface = Color(0xFFFFFFFF)
val DarkBackground = Color(0xFF1F1B12)
val DarkSurface = Color(0xFF2E291B)
